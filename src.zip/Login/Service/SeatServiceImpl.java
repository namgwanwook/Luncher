package Login.Service;

import java.util.ArrayList;
import javafx.scene.control.ToggleButton;


public class SeatServiceImpl implements SeatService{

	@Override
	public void list(String lblid, ArrayList<ToggleButton> list) {
		// TODO Auto-generated method stub
		// 리스트 객체 받아오는 리스트
		ArrayList<ToggleButton> list1 = list;
		
			// 결제완료 후 적용 할 기능(미리 구현)			
			for(int i=0;i<list1.size();i++) {
				if(list1.get(i).getId().equals(lblid)) {
					list1.get(i).setDisable(true);list1.get(i).setStyle("-fx-background-color:skyblue; -fx-background-radius:10px");
				}	
				
		}
	}


}
