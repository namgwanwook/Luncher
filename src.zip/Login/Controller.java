package Login;

import javafx.scene.Parent;

public abstract class Controller {
	public abstract void setRoot(Parent root);
}
