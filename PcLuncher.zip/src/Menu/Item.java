package Menu;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;

public class Item {
	private StringProperty name;
	private IntegerProperty price;
	private IntegerProperty quantity;

	public Item(StringProperty name, IntegerProperty price, IntegerProperty quantity) {
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}

	public StringProperty nameProperty() {
	    return name;
	}
	public IntegerProperty priceProperty() {
	    return price;
	}   
	public IntegerProperty quantityProperty() {
	    return quantity;
	}


	

	
}
