package Menu;

import java.net.URL;
import java.util.ResourceBundle;

import DAO.DatabaseService;
import DAO.DatabaseServiceImpl;
import Menu.Service.CommonService;
import Menu.Service.CommonServiceImpl;
import Menu.Service.MenuService;
import Menu.Service.MenuServiceImpl;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;

public class MenuController extends Controller implements Initializable {

	private Parent root;
	private CommonService comSrv;
	private MenuService menuSrv;
	
	private Item getItems;
	
	// 구입 총 금액
	private int totalPay = 0;

	ObservableList<Item> myList = FXCollections.observableArrayList();

	@FXML	VBox snackVB1;
	@FXML	private TableView<Item> tableView;
	@FXML	private TableColumn<Item, String> name;
	@FXML	private TableColumn<Item, Integer> price;
	@FXML	private TableColumn<Item, Integer> quantity;
	@FXML	private Label exetendedPrice;

	@Override
	public void setRoot(Parent root) {
		Button payBtn = (Button) root.lookup("#pay");
		Button removeAllBtn = (Button) root.lookup("#removeAll");
		payBtn.setDisable(true);
		removeAllBtn.setDisable(true);
		this.root = root;
	}

	// 여기서는 안쓰이지만 Override 된 것들
		@Override
		public void setRoot(Parent root, Controller baseCont, Infomation info) {
		}
	
		@Override
		public void getController(Controller baseCont) {
		}
	// 안쓰는 메서드 여기까지

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		comSrv = new CommonServiceImpl();
		menuSrv = new MenuServiceImpl();
	}

	public void CancelProc(ActionEvent event) {
		comSrv.WindowClose(event);
	}

	public void OpenSelectedMenuForm(ActionEvent event) {
		// 현재 컨트롤러인 MenuController(this)와 누른 버튼의 정보를 받아오는 메서드의 값을 불러와서
		// selectedMenu Form을 열어주는 메서드를 호출
		Parent form = menuSrv.OpenSelectedMenuForm(this, getInfo(event));

	}

	// MenuController의 버튼 이름 입력받고 DB에서 내용 찾아와 객체에 저장
	public Infomation getInfo(ActionEvent event) { // 해당 제품 정보 저장
		
		// 버튼에서 이름 받아옴
		Button Btn = (Button) event.getSource();
		String name = Btn.getText();

		DatabaseService DB = new DatabaseServiceImpl();

		// 버튼의 이름을 통해서 그 제품의 정보를 i에 받아옴
		Infomation i = DB.Select(name);

		// 제대로된 정보 받았는지 콘솔창에서 확인
		System.out.println(name);

		return i;
	}

	// 
	@Override	
	public void getResult(Infomation resultInfo) {
		
		getItems = new Item(new SimpleStringProperty(resultInfo.getImgName()),
				new SimpleIntegerProperty(Integer.parseInt(resultInfo.getImgPrice())),
				new SimpleIntegerProperty(resultInfo.getNum()));

		myList.add(getItems);

		totalPay += (Integer.parseInt(resultInfo.getImgPrice()) * resultInfo.getNum());
		exetendedPrice.setText(Integer.toString(totalPay));
		showList(myList);

	}

	public void showList(ObservableList<Item> list) {
		name.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
		price.setCellValueFactory(cellData -> cellData.getValue().priceProperty().asObject());
		quantity.setCellValueFactory(cellData -> cellData.getValue().quantityProperty().asObject());

		tableView.setItems(list);
		Button payBtn = (Button) root.lookup("#pay");
		Button removeAllBtn = (Button) root.lookup("#removeAll");
		payBtn.setDisable(false);
		removeAllBtn.setDisable(false);

	}

	// 결제 버튼을 누르면 결제 확인을 알리는 메서드
	public void Payment(ActionEvent event) throws InterruptedException {

		comSrv.ErrorMsg(event,"결제", "결제 완료", "등록된 카드로 결제를 진행합니다.");
	}
	
	// 전체 삭제 버튼을 누르면 목록창 초기화
	public void RemoveAll() {
		Button payBtn = (Button) root.lookup("#pay");
		Button removeAllBtn = (Button) root.lookup("#removeAll");
		tableView.getItems().clear();
		payBtn.setDisable(true);
		removeAllBtn.setDisable(true);
		totalPay = 0;
		exetendedPrice.setText(Integer.toString(totalPay));
	}
}
