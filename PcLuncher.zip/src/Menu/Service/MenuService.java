package Menu.Service;

import Menu.Controller;
import Menu.Infomation;
import javafx.scene.Parent;
import javafx.scene.control.Label;

public interface MenuService {
	public Parent OpenSelectedMenuForm();
	public Parent OpenSelectedMenuForm(Controller baseCont, Infomation info);
}
