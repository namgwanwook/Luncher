package Menu.Service;

import javafx.scene.Parent;
import javafx.scene.control.TextField;

public class SelectedMenuServiceImpl implements SelectedMenuService{

	@Override
	public void PlusMinus(Parent root, String oper) {
		TextField quantityTxt = (TextField)root.lookup("#quantity");
		int quantity = Integer.parseInt(quantityTxt.getText());
		
		if(oper.equals("+")) {
			quantity++;
			quantityTxt.setText(quantity+"");
		}
		if(oper.equals("-")){
			if(quantity == 1) {
				return;
			}
			quantity--;
			quantityTxt.setText(quantity+"");
		}
		
	}

	
}
