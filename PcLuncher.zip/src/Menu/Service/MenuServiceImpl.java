package Menu.Service;


import Menu.Controller;
import Menu.Infomation;
import javafx.scene.Parent;
import javafx.stage.Stage;

public class MenuServiceImpl implements MenuService{

	@Override
	public Parent OpenSelectedMenuForm() {
		// 클릭된 제품의 수량을 받기위한 창을 띄우는 메서드1
		
		CommonService comSrv = new CommonServiceImpl();
		Stage seletedMenuForm = new Stage();
		Parent form = comSrv.showWindow(seletedMenuForm, "../selectedMenu.fxml");
		return form;
	}
	
	@Override
	public Parent OpenSelectedMenuForm(Controller baseCont, Infomation info) {
		// 클릭된 제품의 수량을 받기위한 창을 띄우는 메서드2
		
		CommonService comSrv = new CommonServiceImpl();
		Stage seletedMenuForm = new Stage();
		Parent form = comSrv.showWindow(seletedMenuForm, "../selectedMenu.fxml", baseCont, info);
		return form;
	}

	public void setExetendedPrice() {
		
	}

}
