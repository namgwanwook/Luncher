package Menu.Service;

import javafx.scene.Parent;

public interface SelectedMenuService {
	public void PlusMinus(Parent root, String oper);
}
