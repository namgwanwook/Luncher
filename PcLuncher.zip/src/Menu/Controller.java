package Menu;

import javafx.scene.Parent;

public abstract class Controller {
	public abstract void setRoot(Parent root);
	public abstract void setRoot(Parent root, Controller baseCont, Infomation info);
	public abstract void getController(Controller baseCont);
	public abstract void getResult(Infomation info);
}
