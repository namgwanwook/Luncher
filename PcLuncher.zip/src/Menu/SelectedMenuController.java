package Menu;

import java.net.URL;
import java.util.ResourceBundle;

import Menu.Service.CommonService;
import Menu.Service.CommonServiceImpl;
import Menu.Service.SelectedMenuService;
import Menu.Service.SelectedMenuServiceImpl;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class SelectedMenuController extends Controller implements Initializable{
	
	private Parent root;
	private CommonService comSrv;
	private SelectedMenuService selecSrv;
	@FXML ImageView ProductImg;
	@FXML Label setName;
	@FXML Label setPrice;
	@FXML TextField quantity;
	Controller menuController;
	Infomation info;
	Item item;

	
	public void setRoot(Parent root) {} //여기서는 안쓰이지만 Override 된 것
	
	public void setRoot(Parent root, Controller baseCont, Infomation info) {
		this.root = root;
		this.menuController = baseCont;
		
		
		try { 	/*	setRoot 가 실행되면서 
					selectedMenu에 이미지, 제품명, 가격 Set 시켜줌
					
		 			*/
			ProductImg.setImage(new Image(info.getImgInfo()));
			setName.setText(info.getImgName());
			setPrice.setText(info.getImgPrice());

			this.info = info;

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		comSrv = new CommonServiceImpl();
		selecSrv = new SelectedMenuServiceImpl();
	}

	
	public void CancelProc(ActionEvent event) {
		comSrv.WindowClose(event);
	}

	@Override
	public void getController(Controller baseCont) {
		menuController = baseCont;
	}

	public void PlusMinus(ActionEvent event) {
		String oper = ((Button)event.getSource()).getText();
		selecSrv.PlusMinus(root,oper);
	}
	
	// 확인을 누르면 textfield 정보를 받고 창 닫아줌
	public void AddList(ActionEvent event) {
		getResult(info);
		comSrv.WindowClose(event);
	}

	// 선택한 품목의 개수 받아서 info에 추가해줌
	@Override
	public void getResult(Infomation info) {
		int num = Integer.parseInt(quantity.getText());
		
		System.out.println("받아온 개수 출력 : " + quantity.getText());
		info.setNum(num);
		// menuController의 listView에 값을 넘겨줌
		menuController.getResult(info);
	}
		
		

}
