package Service;

import java.io.IOException;
import java.util.List;

import DAO.DatabaseService;
import DAO.DatabaseServiceImpl;
import Login.Controller;
import Login.Member;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginServiceImpl  implements LoginService{
	

	@Override
	public boolean LoginProc(Parent root) {
		SeatService seatSrv = new SeatServiceImpl();
		TextField idTxt = (TextField)root.lookup("#idTxt");
		TextField pwTxt = (TextField)root.lookup("#pwTxt");
		
		
	    
	    Member member = new Member();
	    member.setId(idTxt.getText());
	      
		DatabaseService db = new DatabaseServiceImpl();
		boolean login = db.Select(idTxt.getText(), pwTxt.getText());
		CommonService comSrv = new CommonServiceImpl();
		
		if(login) {
	      System.out.println("로그인 성공 유저의 상태창으로 넘어갑니다");
		} else {
			comSrv.ErrorMsg("Error", "아이디 또는 패스워드가 틀립니다.", "다시 시도해 주세요");
		return false;
		}
		
		//최종 정상 기능시 삭제. 테스트 출력 메세지.
		System.out.println("LoginProc() Test Message:\nID : "+idTxt.getText()+"\nPW : "+pwTxt.getText());
		return true;
	}

	@Override
	public Parent OpenMembershipForm() {
		CommonService comSrv = new CommonServiceImpl();
		Stage membershipForm = new Stage();
		Parent form = comSrv.ShowWindow(membershipForm, "../Login/Membership.fxml","id","seat");
		//최종 정상 기능시 삭제. 테스트 출력 메세지
		
		System.out.println("정상적으로 OpenMembershipForm() 기능");
		return form;
	}

	@Override
	public Parent State(Parent root,Controller cont,String id,String seat) {//유저 상태창을 여는
		Stage s = new Stage();
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../Login/userfxml.fxml"));

		try {
			root = loader.load();
			s.setScene(new Scene(root));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		cont = loader.getController();
		cont.setRoot(root,cont,id,seat);
		s.show();

		//최종 정상 기능시 삭제. 테스트 출력 메세지
		
		System.out.println("정상적으로 State() 기능");
		return root;
	}
	
	
}
