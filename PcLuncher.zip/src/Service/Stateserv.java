package Service;

import Login.Controller;
import Login.Member;
import javafx.event.ActionEvent;
import javafx.scene.Parent;

public interface Stateserv {
	
	public void Countime (Parent root,Controller cont,String id,String seat);
	public void stop (ActionEvent e);//스레드 멈춤
}
