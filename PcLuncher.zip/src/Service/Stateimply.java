package Service;

import java.util.List;

import DAO.DatabaseService;
import DAO.DatabaseServiceImpl;
import Login.Controller;
import Login.Member;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.Parent;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Stateimply implements Stateserv {
	CommonService com = new CommonServiceImpl();
	DatabaseService db = new DatabaseServiceImpl();
	int time; //줄어들 시간
	private boolean stop=true;
	//String set="C8";  //임시 컴퓨터 자리
	
 
	@Override
	public void Countime(Parent root,Controller cont,String id,String seat) {//시간 추가방법 구상
		// TODO Auto-generated method stub
	  
		TextField timetxt = (TextField)root.lookup("#time");
		TextField name = (TextField)root.lookup("#name");
		TextField com = (TextField)root.lookup("#com");
		TextField total = (TextField)root.lookup("#total");
		
		
		
		Thread thread = new Thread() {
			@Override
			public void run() {
				com.setText(seat);
				List a = db.UserInfo(id); 
				time=(int) a.get(2);
				System.out.println(time);
				name.setText((String)a.get(3));
				System.out.println(time+"시작시간"); 
				
				
				while(stop) {
					
				time++;
				System.out.println(time+"지나간시간");
				Platform.runLater(() -> {
					int fee = ((time/60)*1000)+1000; 
					String feetxt =Integer.toString(fee);
					total.setText(feetxt+"원");
					
					int hour = (time/60);
					int min	 = (time%60);
					
					String totaltimehour = Integer.toString(hour);
					String totaltimemin = Integer.toString(min);
					
					timetxt.setText(totaltimehour+"시간"+totaltimemin+"분");
				fee = (Integer.parseInt(feetxt));
					
					
				db.timeupdate(id, time); //<=시간값과 총이용금액 setter 로 보낼것
				db.payupdate(id, fee);
				}); //1000 -> 1초
				try {Thread.sleep(1000);}catch(InterruptedException inter) {}
				}	
			}
		};
		thread.setDaemon(true);
		thread.start();
	}
	
	
	public void stop (ActionEvent e) {
		stop = false;
	}
}
