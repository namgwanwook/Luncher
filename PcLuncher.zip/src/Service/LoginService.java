package Service;

import Login.Controller;
import Login.Member;
import javafx.scene.Parent;

public interface LoginService {
	//로그인 서비스
	public boolean LoginProc(Parent root);//로그인 기능 구현
	public Parent OpenMembershipForm();//회원가입 창 열기
	public Parent State(Parent root,Controller cont,String id,String seat);//상태 창 열기
}
