package Service;

import java.util.ArrayList;

import javafx.scene.control.ToggleButton;

public interface SeatService {
	// 좌석 선택시 디스에이블 기능
	public void list(String lblid, ArrayList<ToggleButton> list);
	
	//임시(true/false)
	public boolean selectedOrNot(boolean b);

}
