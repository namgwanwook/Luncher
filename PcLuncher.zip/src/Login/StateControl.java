package Login;

import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.ResourceBundle;

import DAO.DatabaseService;
import DAO.DatabaseServiceImpl;
import Menu.MenuController;
import Service.CommonService;
import Service.CommonServiceImpl;
import Service.Stateimply;
import Service.Stateserv;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.Parent;

import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class StateControl extends Controller implements Initializable {

	private Parent root;
	private DatabaseService db;
	private Stateserv state;
	private CommonService com;
	Controller StateControl;
	Member member;
	String id;
	String seat;

	@Override
	public void setRoot(Parent root) {
	}

	@Override
	public void setRoot(Parent root, Controller cont, String id, String seat) {
		System.out.println("유저상태창 실행");

		this.root = root;
		this.StateControl = cont;
		this.id = id;
		this.seat = seat;
		try {
			state.Countime(root, cont, id, seat);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		db = new DatabaseServiceImpl();
		state = new Stateimply();
		com = new CommonServiceImpl();

	}

	public void seat(ActionEvent e) {
		//
		Stage s = new Stage();
		com.ShowWindow(s, "../Login/SeatMain.fxml", id, seat);
		com.CloseWindow(root);
	}

	public void order(ActionEvent e) {
		// 음식 주문
		Stage orderForm = new Stage();
		
		MenuController m = new MenuController();

		Menu.Service.CommonService menuComSrv = new Menu.Service.CommonServiceImpl();
		
		menuComSrv.showWindow(orderForm, "../menu.fxml", m);
		System.out.println("여기3");

	}

	public void end(ActionEvent e) { // 종료버튼
		state.stop(e);
		Stage s = new Stage();
		com.ShowWindow(s, "../Login/charge.fxml", id, seat);
	}

}
