package Login;

import Service.CommonService;
import Service.CommonServiceImpl;
import javafx.application.Application;
import javafx.stage.Stage;

public class SeatMain extends Application {
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		CommonService comSrv = new CommonServiceImpl();
		comSrv.ShowWindow(primaryStage, "../Login/SeatMain.fxml","id","seat");
		
        
	}
	public static void main(String[] args) {
		System.out.println(args);
		launch(args);
	}

}
