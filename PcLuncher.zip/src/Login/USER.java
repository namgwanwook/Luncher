package Login;

public class USER {
	private String id;
	private String set;
	
	public  USER (String id) {
		this.id = id;
		
	}
	
	public String id () {
		return id;
	}
	public String set() {
		return set;
	}
}
