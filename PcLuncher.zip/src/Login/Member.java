package Login;

public class Member {
	private String id;
	private String pw;
	private String name;
	private String CardNum;
	private String set;
	public String getSet() {
		return set;
	}
	public void setSet(String set) {
		this.set = set;
	}
	private int time;
	private int payment;
	
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public int getPayment() {
		return payment;
	}
	public void setPayment(int payment) {
		this.payment = payment;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCardNum() {
		return CardNum;
	}
	public void setCardNum(String cardNum) {
		this.CardNum = CardNum;
	}
	
}
