package Login;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import DAO.DatabaseService;
import DAO.DatabaseServiceImpl;
import Service.CommonService;
import Service.CommonServiceImpl;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ChargeController extends Controller implements Initializable{
	DatabaseService db = new DatabaseServiceImpl();
	String name = "asd";
	String payment = "123";
	private Parent root;
	Controller ChargeControl;
	String id;
	@FXML
	private TextField txt1;
	@FXML
	private TextField txt2;
	
	@FXML
	private Button btn;
	
	
	@Override
	public void setRoot(Parent root) {
		this.root = root;
	}
	@Override
	public void setRoot(Parent root,Controller cont,String id,String seat) {
		this.root = root;
		this.ChargeControl=cont;
		this.id=id;
		System.out.println(id+"chargecontrol아이디를 받아오니?");
		List a = db.UserInfo(id);
		System.out.println(a+"리스트의 값을 가져왔습니다형님");
		int pay = (int)a.get(4);
		String paytxt = Integer.toString(pay);
		txt1.setText(id);
		txt2.setText(paytxt+"원");
		
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub	
		
		btn.setOnAction(Event -> Platformexit(Event));
	}
	public void Platformexit(ActionEvent e) {
		
		db.timeupdate(id,0); //결제 완료후 시간 초기화
		db.payupdate(id, 0);//결제 완료후 값 초기화
		
		CommonService com = new CommonServiceImpl();
		com.allclose();
		

	}
	
	
	
	
}
