package Login;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import Service.CommonService;
import Service.CommonServiceImpl;
import Service.SeatService;
import Service.SeatServiceImpl;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;





public class SeatControl extends Controller implements Initializable {
	@FXML private ToggleButton A1,A2,A3,A4,A5,A6,A7,A8,A9,A10,A11,A12;
	@FXML private ToggleButton B1,B2,B3,B4,B5,B6,B7,B8,B9,B10,B11,B12;
	@FXML private ToggleButton C1,C2,C3,C6,C7,C8,C9,C10,C11,C12;
	@FXML private ToggleButton D1,D2,D3,D6,D7,D8,D9,D10,D11,D12;
	// 확인버튼
	@FXML private Button ok;
	@FXML private Label lbl;
	
	CommonService comSrv = new CommonServiceImpl();
	SeatService seSrv = new SeatServiceImpl();
	
	private Parent root; 
	private Controller seatcont;
	String id;
	String seat;
	
	
	public void setRoot(Parent root) {
		this.root = root;
	}
	@Override
	public void setRoot(Parent root,Controller cont,String id,String seat) {
		this.root = root;
		this.seatcont = cont;
		this.id = id;
		this.seat = seat;
		Button btn  = (Button)root.lookup(seat);
		
		boolean b = false;
		ok.setDisable(seSrv.selectedOrNot(b));
		System.out.println("여기보세요~~~~ "+seat);
		try {
			if(!id.equals("id")) {
				lbl.setText(seat);
				System.out.println(root);
				ToggleButton tb = (ToggleButton)root.lookup("#"+seat);
				System.out.println(tb);
				tb.setDisable(true);
				tb.setStyle("-fx-background-color :skyblue;"
						+ "-fx-border-radius : 10; "
						+ "-fx-background-radius :10;"
						+ "-fx-border-width :  3; "
						+ "-fx-background-insets :  1;"
						+ "-fx-opacity:1");
			};			
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		//토글그룹 담는 리스트
		ArrayList<ToggleButton> list = new ArrayList<ToggleButton>();;

		
		// 토글그룹 변수
		ToggleGroup group = new ToggleGroup();
		
		
		// 토글버튼 리스트에 추가
		list.add(A1);list.add(A2);list.add(A3);list.add(A4);list.add(A5);list.add(A6);
		list.add(A7);list.add(A8);list.add(A9);list.add(A10);list.add(A11);list.add(A12);	
		list.add(B1);list.add(B2);list.add(B3);list.add(B4);list.add(B5);list.add(B6);
		list.add(B7);list.add(B8);list.add(B9);list.add(B10);list.add(B11);list.add(B12);		
		list.add(C1);list.add(C2);list.add(C3);list.add(C6);list.add(C7);
		list.add(C8);list.add(C9);list.add(C10);list.add(C11);list.add(C12);		
		list.add(D1);list.add(D2);list.add(D3);list.add(D6);list.add(D7);
		list.add(D8);list.add(D9);list.add(D10);list.add(D11);list.add(D12);

		
		// 토글버튼을 그룹에 추가
		for(int k=0;k<list.size();k++) {
			list.get(k).setToggleGroup(group);
		}
		
		System.out.println(list.get(1));
		
	    // 좌석 칸에 뜨는 좌석 번호 초기화 변수(1 ~ 12까지만 뜸)
		int cnt = 1;
		
		// 좌석 번호 표시
		// A열
		for(int i=0;i<12;i++) {
			
			ToggleButton tb;
			String a = "A"+(i+1);
			tb = list.get(i);
			list.get(i).setOnAction(e->
			{	
				lbl.setText(a);
				ok.setDisable(seSrv.selectedOrNot(true));
			}
			);}	
		
		// B열
		for(int i=12;i<24;i++) {
			String b = "B"+cnt;			
			list.get(i).setOnAction(e->
			{
				lbl.setText(b); 
				ok.setDisable(seSrv.selectedOrNot(true));
			});	
			cnt += 1;
			if(cnt>12) {
				cnt = 1;
			}
		}	
		
		// C열
		for(int i=24;i<34;i++) {
			String c = "C"+cnt;
			list.get(i).setOnAction(e->
			{
				lbl.setText(c); 
				ok.setDisable(seSrv.selectedOrNot(true));
			});	
			if(i==26) {
				cnt += 2;
			}
			cnt += 1;
			if(cnt>12) {
				cnt = 1;
			}
		}	
		
		// D열
		for(int i=34;i<44;i++) {
			String d = "D"+cnt;		
			list.get(i).setOnAction(e->
			{
				lbl.setText(d); 
				ok.setDisable(seSrv.selectedOrNot(true));
			});	
			if(i==36) {
				cnt += 2;
			}
			cnt += 1;
			if(cnt>12) {
				cnt = 1;
			}
		}	

		// 확인 버튼 클릭시 로그인 팝업창
		ok.setOnAction(e-> {
			Stage LoginFrom = new Stage();
			comSrv.ShowWindow(LoginFrom,"../Login/Login.fxml","id",lbl.getText());
			String lblid = lbl.getText();
			comSrv.CloseWindow(root);
			
			//seSrv.list(lblid, list); //파래지는 얘들
			
		});
	}
//	public void seatClicked(ActionEvent event) {
//		
//		ToggleButton tb = (ToggleButton)root.lookup("#"+lbl.getText());
//		tb.setStyle("-fx-background-color :#ffffff;");
//	}

	
}
	
