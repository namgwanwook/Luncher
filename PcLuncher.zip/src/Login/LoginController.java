package Login;

import java.net.URL;
import java.util.Map;
import java.util.ResourceBundle;

import DAO.DatabaseService;
import DAO.DatabaseServiceImpl;
import Service.CommonService;
import Service.CommonServiceImpl;
import Service.LoginService;
import Service.LoginServiceImpl;
import Service.MembershipService;
import Service.MembershipServiceImpl;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController extends Controller implements Initializable{

	private Parent root;
	private CommonService comSrv;
	private LoginService loginSrv;
	private MembershipService memSrv;
	@FXML TextField idTxt;
	Controller statecontroller;
	String seat;
	
	@Override
	public void setRoot(Parent root) {
		this.root=root;
	}
	@Override
	public void setRoot(Parent root,Controller cont,String id,String seat) {
		this.root=root;
		this.statecontroller=cont;
		this.seat=seat;
	}
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		comSrv = new CommonServiceImpl();
		loginSrv = new LoginServiceImpl();
		memSrv = new MembershipServiceImpl();
	}
	
	public void LoginProc() {
		//로그인 기능 구현
		String []txtFldArr = {"#idTxt", "#pwTxt"};
		String []list = {"아이디", "패스워드"};
		Map<String, TextField> txtFldMap = comSrv.getTextFldInfo(root, txtFldArr);

		
		if (comSrv.isEmpty(txtFldMap, txtFldArr, list)) {
			
			return;
		}
	
		if(loginSrv.LoginProc(root)) {
			
			Parent form=loginSrv.State(root, this,idTxt.getText(),seat);
			
			comSrv.CloseWindow(root);
		}
		
		
	}
	
	public void CancelProc(ActionEvent event) {
		Stage s = new Stage();
		comSrv.ShowWindow(s, "../Login/SeatMain.fxml", "a","b");
		comSrv.CloseWindow(event);
	}
	
	public void OpenMembershipForm() {
		Parent form = loginSrv.OpenMembershipForm();
	}
	
	
}
