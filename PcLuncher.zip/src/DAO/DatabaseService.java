package DAO;

import java.sql.SQLException;
import java.util.List;

import Login.Member;
import Menu.Infomation;

public interface DatabaseService {
	public void Insert(Member member) throws SQLException;
	public boolean Select(String id, String pw);
	
	// 메뉴
	public Infomation Select(String name);
	
	public List<Object> UserInfo (String id); //남은시간을 불러옴
	public void  timeupdate (String id,int time); // 종료시 남은시간 업데이트
	public void payupdate (String id,int time); //사용금액 업데이트
}
