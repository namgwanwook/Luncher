package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Login.Member;
import Menu.Infomation;

public class DatabaseServiceImpl implements DatabaseService{
	
	final static String DRIVER = "oracle.jdbc.driver.OracleDriver";
	final static String url = "jdbc:oracle:thin:@127.0.0.1:1521:XE";
	final static String user = "system";
	final static String pass = "oracle";
	
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	private List<Object> list = new ArrayList(); //회원정보 리스트
	private Infomation Info; // 메뉴에서 사용
	
	static {
		try {
			Class.forName(DRIVER);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void Insert(Member member) throws SQLException {
		
		try {
			con = DriverManager.getConnection(url, user, pass);
			String sql = "insert into member_1 values(?,?,?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, member.getId());
			ps.setString(2, member.getPw());
			ps.setString(3, member.getName());
			ps.setInt(4, member.getTime());
			ps.setInt(5, member.getPayment());
			int res = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean Select(String id, String pw) {
		boolean result = true;
		
		try {
			con = DriverManager.getConnection(url, user, pass);
			String sql = "select * from member_1 where id=? and pw=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2, pw);
			rs = ps.executeQuery();
			if (rs.next() == false) {
				return false;
			}
			rs.close();
			ps.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	
	@Override
	public Infomation Select(String name) {
		// TODO Auto-generated method stub
		
		try {
			con = DriverManager.getConnection(url,user,pass);
			String sql = "select * from products where name=?";
			ps = con.prepareStatement(sql);
			ps.setString(1,name);
			rs = ps.executeQuery();	
			
			if(!rs.next()) {
				System.out.println("데이터 없음");
				return null;
			}
			
			int price = rs.getInt("price");
			String img = rs.getString("img");
			int quantity = rs.getInt("quantity");
			int selected = rs.getInt("selected");
			
			
			System.out.println("정보들 나열 : " + name + " / " + price + " / " + img + " / " + quantity + " / " + selected);
			
			Info = new Infomation(name, Integer.toString(price), img);
			
			rs.close();
			ps.close();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return Info;
	}
	

	@Override
	public List<Object> UserInfo(String id) { 
		// TODO Auto-generated method stub
		try {
			con = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "system", "oracle");
			String sql = "select * from member_1 where id = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, id);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
			list.add(rs.getString("id"));
			list.add(rs.getString("pw"));
			list.add(rs.getInt("time"));
			list.add(rs.getString("name"));
			list.add(rs.getInt("payment"));
			}
			
			int a = ps.executeUpdate();
			
				} catch (Exception e) {
					e.printStackTrace();
					}
		return list;
	}

	@Override
	public void timeupdate(String id,int time) { //예상치못한 강제종료에 의해 값 사라지는 것을 방지
		
		try {
			con = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "system", "oracle");
			String sql = "update member_1 set time = ? where id = ?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, time);
			ps.setString(2, id);
			
			ps.executeUpdate();
			
			sql="commit";
			ps=con.prepareStatement(sql);
			
			ps.executeUpdate();
			System.out.println("업데이트완료");
			
			rs.close();
			ps.close();
			con.close();
			
				} catch (Exception e) {
					e.printStackTrace();
					}
	}

	@Override
	public void payupdate(String id, int payment) {////예상치못한 강제종료에 의해 값 사라지는 것을 방지
		try {
			con = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:XE", "system", "oracle");
			String sql = "update member_1 set payment = ? where id = ?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, payment);
			ps.setString(2, id);
			
			
			ps.executeUpdate();
			
			sql="commit";
			ps=con.prepareStatement(sql);
			
			ps.executeUpdate();
			System.out.println("업데이트완료");
			
			rs.close();
			ps.close();
			con.close();
			
				} catch (Exception e) {
					e.printStackTrace();
					}
		
	}

}
